import pandas as pd
import numpy as np
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, chi2
from sklearn.model_selection import GridSearchCV

# Text cleaning functions
def remove_html(text):
    """Remove HTML tags using regex."""
    html = re.compile(r'<.*?>')
    return html.sub(r'', text)

def remove_emoji(text):
    """Remove emojis using regex pattern."""
    emoji_pattern = re.compile("[" 
                               u"\U0001F600-\U0001F64F"  # emoticons
                               u"\U0001F300-\U0001F5FF"  # symbols & pictographs
                               u"\U0001F680-\U0001F6FF"  # transport & map symbols
                               u"\U0001F1E0-\U0001F1FF"  # flags
                               u"\U00002702-\U000027B0"
                               u"\U000024C2-\U0001F251"  # enclosed characters
                               "]+", flags=re.UNICODE)
    return emoji_pattern.sub(r'', text)

def remove_stopwords(text, stopwords_list):
    """Remove stopwords from the text."""
    return " ".join([word for word in text.split() if word not in stopwords_list])

def clean_str(string):
    """Clean the text by removing non-alphanumeric characters and making it lowercase."""
    string = re.sub(r"[^A-Za-z0-9(),.!?\'\`]", " ", string)
    string = re.sub(r"\'s", " \'s", string)
    string = re.sub(r"\'ve", " \'ve", string)
    string = re.sub(r"\)", " ) ", string)
    string = re.sub(r"\?", " ? ", string)
    string = re.sub(r"\s{2,}", " ", string)
    return string.strip().lower()

# Load the data
def load_data(file_path):
    """Load data from CSV and preprocess."""
    data = pd.read_csv(file_path)
    
    # Merging Title and Body into one column
    data['text'] = data.apply(lambda row: row['Title'] + ' ' + (row['Body'] if pd.notna(row['Body']) else ''), axis=1)
    
    # Clean the text data
    data['text'] = data['text'].apply(remove_html)
    data['text'] = data['text'].apply(remove_emoji)
    # Assuming stopwords_list is predefined
    stopwords_list = set(["the", "and", "is", "to", "of", "a", "in", "it", "for", "with", "on", "this", "as"]) # example stop words
    data['text'] = data['text'].apply(lambda x: remove_stopwords(x, stopwords_list))
    data['text'] = data['text'].apply(clean_str)
    
    return data

# Train and evaluate the model using improved SVM
def train_and_evaluate(data, repeat=10):
    accuracies, precisions, recalls, f1_scores, auc_scores = [], [], [], [], []
    
    # StratifiedKFold ensures balanced class distribution in train and test sets
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)  # Use 5-fold cross-validation
    
    # Initialize TF-IDF vectorizer with improvements
    tfidf = TfidfVectorizer(ngram_range=(1, 3), max_features=5000, sublinear_tf=True, stop_words='english')
    
    # Define target labels
    y = data['class']
    X = tfidf.fit_transform(data['text'])
    
    # Optional: Standardize the features
    scaler = StandardScaler(with_mean=False)
    X = scaler.fit_transform(X)
    
    # Apply feature selection using SelectKBest (Chi2)
    selector = SelectKBest(chi2, k=1000)
    X = selector.fit_transform(X, y)
    
    # SVM Hyperparameter tuning with GridSearchCV
    param_grid = {
        'C': [0.1, 1, 10, 100],
        'kernel': ['linear', 'rbf'],
        'gamma': ['scale', 'auto'],
    }
    svm = SVC(random_state=42)
    grid_search = GridSearchCV(svm, param_grid, cv=5, n_jobs=-1, scoring='accuracy')
    
    for train_idx, test_idx in skf.split(X, y):
        X_train, X_test = X[train_idx], X[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]
        
        # Fit the best SVM model
        grid_search.fit(X_train, y_train)
        best_model = grid_search.best_estimator_

        # Predict the test data
        y_pred = best_model.predict(X_test)
        
        # Calculate metrics
        acc = accuracy_score(y_test, y_pred)
        prec = precision_score(y_test, y_pred)
        rec = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        auc = roc_auc_score(y_test, y_pred)
        
        # Store metrics
        accuracies.append(acc)
        precisions.append(prec)
        recalls.append(rec)
        f1_scores.append(f1)
        auc_scores.append(auc)
    
    # Calculate the average scores across repeats
    avg_acc = np.mean(accuracies)
    avg_prec = np.mean(precisions)
    avg_rec = np.mean(recalls)
    avg_f1 = np.mean(f1_scores)
    avg_auc = np.mean(auc_scores)
    
    return avg_acc, avg_prec, avg_rec, avg_f1, avg_auc

# Main function
def main():
    # Path to your dataset (adjust accordingly)
    data_file = "incubator-mxnet.csv"
    
    # Load and preprocess the data
    data = load_data(data_file)
    
    # Run training and evaluation (repeat 10 times as example)
    avg_acc, avg_prec, avg_rec, avg_f1, avg_auc = train_and_evaluate(data, repeat=30)
    
    # Output results
    print("=== Model Evaluation Results ===")
    print(f"Average Accuracy: {avg_acc:.4f}")
    print(f"Average Precision: {avg_prec:.4f}")
    print(f"Average Recall: {avg_rec:.4f}")
    print(f"Average F1 Score: {avg_f1:.4f}")
    print(f"Average AUC: {avg_auc:.4f}")
    
    # Optionally, save results to CSV
    result_df = pd.DataFrame({
        'Metric': ['Accuracy', 'Precision', 'Recall', 'F1 Score', 'AUC'],
        'Value': [avg_acc, avg_prec, avg_rec, avg_f1, avg_auc]
    })
    result_df.to_csv("evaluation_results.csv", index=False)

# Run the main function
if __name__ == "__main__":
    main()

